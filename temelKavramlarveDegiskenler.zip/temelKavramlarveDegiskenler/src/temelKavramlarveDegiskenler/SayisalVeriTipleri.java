package temelKavramlarveDegiskenler;

public class SayisalVeriTipleri {

	public static void main(String[] args) {
		byte abc = 100;
		System.out.println(abc);
		System.out.println("abc");
		System.out.println(100);
		
		short xyz = 128;
		System.out.println(xyz);
		System.out.println("xyz");
		System.out.println(128);
		
		int intDeger =1000000000;
		System.out.println("Integer degeri : "+ intDeger);
		
		long longDeger = 7828734987472483749l;
		System.out.println("Long degeri :"+ longDeger);
		

	}

}
