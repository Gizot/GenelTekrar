package temelKavramlarveDegiskenler;

public class StringVeriTipi {

	public static void main(String[] args) {

		char a = 'm';
		char b = 'M';
		
		char x = 117;
		char y = 62;
		
		char e = 64;
		char f = '!';
		
		System.out.println(a);
		System.out.println(b);
		System.out.println(x);
		System.out.println(y);
		System.out.println(e);
		System.out.println(f);
		
		String str = "Hello World!";
		System.out.println(str);
		
		String metin = "Selam Dünya!";
		System.out.println(metin);
		System.out.println("15" + 20);
		System.out.println(15+20);
		
	}

}
