package temelKavramlarveDegiskenler;

public class OndalikliVeriTipleri {

	public static void main(String[] args) {

		//float değerinin sonuna f ya da F eklemen gerekir
		float sayi1 = 34.0f;
		float sayi2 = 35.1f;
		float sayi3 = 36f;
		
		System.out.println(sayi1+sayi2+sayi3);
		
		double ondalikliSayi1=3;
		double ondalikliSayi2=3.14;
		System.out.println(ondalikliSayi1);
		ondalikliSayi1=54.8;
		System.out.println(ondalikliSayi1);
	}

}
